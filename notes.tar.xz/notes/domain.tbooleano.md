---
id: 2nacgyiv91ysvmijvm03wz2
title: TBOOLEANO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TBOOLEANO AS CHAR(1);
```
