---
id: 7if6usmelukr6g79tl6p066
title: TCADENAMEDIANA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCADENAMEDIANA AS VARCHAR(50);
```
