---
id: 49zlotrdrv4bzai23dey2me
title: TCANTIDAD
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCANTIDAD AS FLOAT;
```
