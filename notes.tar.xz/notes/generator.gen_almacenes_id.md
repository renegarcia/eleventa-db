---
id: 5lsx3azy39ba7ztoyf38qkm
title: GEN_ALMACENES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_ALMACENES_ID;
```
