---
id: 1duef0yur6zyplws9lyzs9y
title: PK_USUARIO_UNICO
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE UNIQUE INDEX PK_USUARIO_UNICO ON USUARIOS (USUARIO, ELIMINADO_EN);
```
