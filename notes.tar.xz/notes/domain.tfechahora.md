---
id: 81qw3t5g5amu2mplahyj16x
title: TFECHAHORA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFECHAHORA AS TIMESTAMP;
```
