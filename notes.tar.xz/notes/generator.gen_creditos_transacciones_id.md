---
id: 5x2qumgphzihtgtph6as1w6
title: GEN_CREDITOS_TRANSACCIONES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CREDITOS_TRANSACCIONES_ID;
```
