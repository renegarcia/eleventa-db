---
id: 3sjqszulee8gnvkbqkmobqr
title: TFACTURAFOLIOOPCIONAL
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFACTURAFOLIOOPCIONAL AS INTEGER;
```
