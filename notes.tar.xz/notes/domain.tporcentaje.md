---
id: 6lxvqychejwgs901k44pjg6
title: TPORCENTAJE
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TPORCENTAJE AS SMALLINT
         DEFAULT 0;
```
