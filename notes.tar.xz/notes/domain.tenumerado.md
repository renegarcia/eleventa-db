---
id: iezwv2qocicowbgvgssm7mm
title: TENUMERADO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TENUMERADO AS CHAR(1);
```
