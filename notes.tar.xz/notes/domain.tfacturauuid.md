---
id: 6zvkqzg7oknsi6ihhhgnmn3
title: TFACTURAUUID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFACTURAUUID AS VARCHAR(38);
```
