---
id: 1frbcjh084f7oe6jvsw69nm
title: TFECHA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFECHA AS DATE;
```
