---
id: 7xmdkmeo95tjq4mj86apedk
title: GEN_VENTA_DE_RECARGAS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_VENTA_DE_RECARGAS_ID;
```
