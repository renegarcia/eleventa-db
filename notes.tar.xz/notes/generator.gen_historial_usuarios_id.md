---
id: 3kzvrj73fugdt5cegmigls7
title: GEN_HISTORIAL_USUARIOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_HISTORIAL_USUARIOS_ID;
```
