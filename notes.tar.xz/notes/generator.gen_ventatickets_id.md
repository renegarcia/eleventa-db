---
id: 6agcndlx8sk0sb876j6c2mn
title: GEN_VENTATICKETS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_VENTATICKETS_ID;
```
