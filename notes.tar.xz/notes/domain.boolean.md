---
id: pe9rethbbqp3b0opbaxszl1
title: BOOLEAN
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN "BOOLEAN" AS SMALLINT;
```
