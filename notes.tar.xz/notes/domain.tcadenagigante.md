---
id: aop8p5bhg125xxya6x8a7uz
title: TCADENAGIGANTE
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCADENAGIGANTE AS VARCHAR(1000);
```
