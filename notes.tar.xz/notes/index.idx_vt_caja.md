---
id: ufckjb8s1jm1800by8wb7mc
title: IDX_VT_CAJA
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IDX_VT_CAJA ON VENTATICKETS (CAJA_ID);
```
