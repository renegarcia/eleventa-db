---
id: 64g2ji0g6ql37kvsi0mbzew
title: GEN_SINCRONIZACION_NUBE_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_SINCRONIZACION_NUBE_ID;
```
