---
id: 7n7ao13gicnfyl0gek7vtea
title: GEN_CORTE_VENTAS_POR_DEPTO_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CORTE_VENTAS_POR_DEPTO_ID;
```
