---
id: zaeprrcd8wijs2zrcn7s38q
title: TFACTURAVERSION
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFACTURAVERSION AS VARCHAR(4)
         DEFAULT '2.2';
```
