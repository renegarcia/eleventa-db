---
id: 783in5jzj6qhhfktxgea20f
title: GEN_CAJAS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CAJAS_ID;
```
