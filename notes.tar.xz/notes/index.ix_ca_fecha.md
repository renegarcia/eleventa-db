---
id: 2sl9njmwx6eix2l9688nyhv
title: IX_CA_FECHA
desc: null
updated: 1684912753
created: 1684912753
---


```sql
CREATE INDEX IX_CA_FECHA ON CREDITOS_ABONOS (FECHA);
```
