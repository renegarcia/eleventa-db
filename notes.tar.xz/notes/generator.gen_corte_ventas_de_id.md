---
id: 1noiclj0ft6jh4hoczs25oy
title: GEN_CORTE_VENTAS_DE_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CORTE_VENTAS_DE_ID;
```
