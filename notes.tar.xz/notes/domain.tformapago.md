---
id: 1wmwv6ydq783069yr0jhfc3
title: TFORMAPAGO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFORMAPAGO AS CHAR(10);
```
