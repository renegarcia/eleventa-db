---
id: 55bbxyl7naef25n2h9m8pnm
title: INVENTARIO_AJUSTE_FOLIO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR INVENTARIO_AJUSTE_FOLIO;
```
