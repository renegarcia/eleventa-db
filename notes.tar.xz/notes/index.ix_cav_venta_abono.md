---
id: 2cctvcc7rs5siqdovdwkshg
title: IX_CAV_VENTA_ABONO
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IX_CAV_VENTA_ABONO ON CREDITOS_ABONOS_VENTAS (VENTA_ID, ABONO_ID);
```
