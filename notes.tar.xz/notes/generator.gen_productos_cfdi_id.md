---
id: 38w2ghj1nx4ynqswtc2b3nz
title: GEN_PRODUCTOS_CFDI_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_PRODUCTOS_CFDI_ID;
```
