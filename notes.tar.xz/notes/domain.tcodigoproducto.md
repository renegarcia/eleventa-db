---
id: 3aihj0jad3e6h4owv3bk1eb
title: TCODIGOPRODUCTO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCODIGOPRODUCTO AS VARCHAR(20);
```
