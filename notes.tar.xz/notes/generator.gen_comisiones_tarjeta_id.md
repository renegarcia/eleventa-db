---
id: 7ikb4xtpipax3yynuzdevbx
title: GEN_COMISIONES_TARJETA_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_COMISIONES_TARJETA_ID;
```
