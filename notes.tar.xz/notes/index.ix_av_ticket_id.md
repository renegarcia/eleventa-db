---
id: 3enhz67qr1zz6cini8h8p5r
title: IX_AV_TICKET_ID
desc: null
updated: 1684912753
created: 1684912753
---


```sql
CREATE INDEX IX_AV_TICKET_ID ON ABONOS_VENTAS (TICKET_ID);
```
