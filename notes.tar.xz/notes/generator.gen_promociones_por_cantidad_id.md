---
id: 4lycked9qxda96h8aihpitc
title: GEN_PROMOCIONES_POR_CANTIDAD_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_PROMOCIONES_POR_CANTIDAD_ID;
```
