---
id: 3uanp5gews3llrohwzwe7ou
title: GEN_ABONOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_ABONOS_ID;
```
