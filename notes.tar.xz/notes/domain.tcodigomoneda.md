---
id: 54b56bb2qwnvw7luq0qpgcj
title: TCODIGOMONEDA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCODIGOMONEDA AS VARCHAR(3);
```
