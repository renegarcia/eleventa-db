---
id: 456bzft8x2tnrge8n3r5wfm
title: TCANTIDADINV
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCANTIDADINV AS DOUBLE PRECISION;
```
