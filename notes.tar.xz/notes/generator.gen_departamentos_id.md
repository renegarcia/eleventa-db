---
id: 7h2khnz2rvf7pypp0ajnroa
title: GEN_DEPARTAMENTOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_DEPARTAMENTOS_ID;
```
