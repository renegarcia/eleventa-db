---
id: 6oas8sbijjmhdk6jaooor4q
title: GEN_VENTA_RECARGA_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_VENTA_RECARGA_ID;
```
