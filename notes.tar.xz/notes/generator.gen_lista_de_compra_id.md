---
id: 48jve1ksqvn34hjtok1chk3
title: GEN_LISTA_DE_COMPRA_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_LISTA_DE_COMPRA_ID;
```
