---
id: 4iobbviwalr53gbfqvefog1
title: IX_CT_REPORTE
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IX_CT_REPORTE ON CREDITOS_TRANSACCIONES (FECHA, VENTA_ID, ABONO_ID);
```
