---
id: 24mdpmbzpd277tvnunq7q49
title: TMONEDA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TMONEDA AS NUMERIC(18, 4);
```
