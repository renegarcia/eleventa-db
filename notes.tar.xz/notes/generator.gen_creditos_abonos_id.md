---
id: 201zn78ccrwam16osn52287
title: GEN_CREDITOS_ABONOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CREDITOS_ABONOS_ID;
```
