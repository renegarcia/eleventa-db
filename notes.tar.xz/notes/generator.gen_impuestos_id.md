---
id: fdftnfkd5ezo7arcegfiqpc
title: GEN_IMPUESTOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_IMPUESTOS_ID;
```
