---
id: 4shktjfirgwdgzrrbgsds1s
title: GEN_CORTE_OPERACIONES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CORTE_OPERACIONES_ID;
```
