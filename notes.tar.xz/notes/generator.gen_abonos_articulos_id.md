---
id: 2zv6an24kpzq6eiej9frli8
title: GEN_ABONOS_ARTICULOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_ABONOS_ARTICULOS_ID;
```
