---
id: kucghqomrx1jibk16mqbq72
title: TNUMEROTRANSACCION
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TNUMEROTRANSACCION AS BIGINT;
```
