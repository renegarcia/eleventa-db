---
id: 88ul5l5yl5e9df980xzu1qz
title: TCADENALARGA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCADENALARGA AS VARCHAR(255);
```
