---
id: 1bl4acf4382lnprxp0pvtzs
title: GEN_MEDIDAS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_MEDIDAS_ID;
```
