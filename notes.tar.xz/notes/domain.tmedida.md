---
id: 5lou899mlwqsh3itnxlaw0p
title: TMEDIDA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TMEDIDA AS VARCHAR(3);
```
