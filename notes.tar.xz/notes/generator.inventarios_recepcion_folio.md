---
id: 3f5aucgvqu3yjkntofqhe69
title: INVENTARIOS_RECEPCION_FOLIO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR INVENTARIOS_RECEPCION_FOLIO;
```
