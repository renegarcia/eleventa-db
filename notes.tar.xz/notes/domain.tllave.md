---
id: 7kgkx2agyrqpxbyqj1ug0z9
title: TLLAVE
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TLLAVE AS INTEGER;
```
