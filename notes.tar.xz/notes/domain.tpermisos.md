---
id: 7d4jq3ruq13g6uy8o48zwhe
title: TPERMISOS
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TPERMISOS AS BLOB SUB_TYPE 0 SEGMENT SIZE 80;
```
