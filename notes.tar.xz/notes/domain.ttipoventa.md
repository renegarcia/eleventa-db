---
id: 7907pvzbjg2242zi51fjbdh
title: TTIPOVENTA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TTIPOVENTA AS CHAR(1) NOT NULL;
```
