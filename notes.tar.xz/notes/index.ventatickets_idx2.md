---
id: rkdilavjhnouvq15dyzaz5y
title: VENTATICKETS_IDX2
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX VENTATICKETS_IDX2 ON VENTATICKETS (ESTA_ABIERTO, ID);
```
