---
id: 66xl4rdh9qntk27sbwmvp7i
title: TTIPOMOVIMIENTO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TTIPOMOVIMIENTO AS CHAR(1);
```
