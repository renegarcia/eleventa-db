---
id: 610sy6mxugf19dy22f19u9r
title: TFOLIO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFOLIO AS INTEGER;
```
