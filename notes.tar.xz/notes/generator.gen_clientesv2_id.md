---
id: 7o8pgkosotex0ri1pcoh4g4
title: GEN_CLIENTESV2_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CLIENTESV2_ID;
```
