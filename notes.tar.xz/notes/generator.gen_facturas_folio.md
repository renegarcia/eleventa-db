---
id: 5mj7wox77a0udahcf1bbbqw
title: GEN_FACTURAS_FOLIO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_FACTURAS_FOLIO;
```
