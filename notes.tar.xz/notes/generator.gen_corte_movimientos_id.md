---
id: 4zruft36a83ssnvjw21bkaq
title: GEN_CORTE_MOVIMIENTOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CORTE_MOVIMIENTOS_ID;
```
