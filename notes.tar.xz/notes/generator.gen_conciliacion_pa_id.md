---
id: 3h412qclqcghz05rluukvli
title: GEN_CONCILIACION_PA_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CONCILIACION_PA_ID;
```
