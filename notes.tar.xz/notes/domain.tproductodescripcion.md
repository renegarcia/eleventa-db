---
id: 3vphdyjlt5t0cn23qxklq6l
title: TPRODUCTODESCRIPCION
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TPRODUCTODESCRIPCION AS VARCHAR(255);
```
