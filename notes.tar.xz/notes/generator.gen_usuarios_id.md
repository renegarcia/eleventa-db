---
id: 167tph5lx3rv0q0kcsfqixn
title: GEN_USUARIOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_USUARIOS_ID;
```
