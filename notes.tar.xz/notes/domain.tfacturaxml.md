---
id: 22za7sasjj4c2tn893tbnh6
title: TFACTURAXML
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFACTURAXML AS BLOB SUB_TYPE 0 SEGMENT SIZE 80;
```
