---
id: 2rzx0gqd3a7tq5qohhse80d
title: GEN_CORTE_IMPUESTOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CORTE_IMPUESTOS_ID;
```
