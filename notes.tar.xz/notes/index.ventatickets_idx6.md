---
id: 34oio8plitcsowa5xk5dwfr
title: VENTATICKETS_IDX6
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX VENTATICKETS_IDX6 ON VENTATICKETS (VENDIDO_EN, FOLIO);
```
