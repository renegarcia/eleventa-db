---
id: 6ekkhi26w6um2qmqv3c17aa
title: IX_FOLIO
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE DESCENDING INDEX IX_FOLIO ON VENTATICKETS (FOLIO);
```
