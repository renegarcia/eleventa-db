---
id: 65sq48gzh49elk0b330nb07
title: TCARACTER
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCARACTER AS CHAR(1);
```
