---
id: 2j8qhjic5jtwsfg4ds12iw8
title: GEN_SERVICIOS_CONSECUTIVO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_SERVICIOS_CONSECUTIVO;
```
