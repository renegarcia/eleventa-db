---
id: 5ig7nai36mucebtwk7147g5
title: GEN_CRED_ARTS_IMPS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CRED_ARTS_IMPS_ID;
```
