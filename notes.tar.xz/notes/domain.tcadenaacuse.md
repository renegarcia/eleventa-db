---
id: 3es95pj59kaar762fpajh45
title: TCADENAACUSE
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCADENAACUSE AS VARCHAR(3000);
```
