---
id: 2pwm2whcvgsnb30gv25ngca
title: TGUID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TGUID AS VARCHAR(38);
```
