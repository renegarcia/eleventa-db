---
id: 5jbdobs7bh1dswg422flj4t
title: TMONEDA_4_DECIMALES
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TMONEDA_4_DECIMALES AS INTEGER;
```
