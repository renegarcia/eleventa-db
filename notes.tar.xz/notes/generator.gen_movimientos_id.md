---
id: 3rs7rcjjee6xa8znnkqxmep
title: GEN_MOVIMIENTOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_MOVIMIENTOS_ID;
```
