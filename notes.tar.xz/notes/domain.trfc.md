---
id: 6p3do0toasncq8f9mmsb5gy
title: TRFC
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TRFC AS VARCHAR(13) NOT NULL;
```
