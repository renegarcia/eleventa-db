---
id: 3pwkfh0d9ex8wclf9ctavsh
title: SCHEMA_INFO
desc: null
updated: 1684912753
created: 1684912753
---


```sql
CREATE TABLE SCHEMA_INFO (VERSION_DB INTEGER);
```
