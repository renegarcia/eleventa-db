---
id: 4l827e3403kp6dxj83s3n4d
title: GEN_TURNOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_TURNOS_ID;
```
