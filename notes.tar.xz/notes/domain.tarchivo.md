---
id: 1lxvi3j75ramxecmuvy05wv
title: TARCHIVO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TARCHIVO AS BLOB SUB_TYPE 0 SEGMENT SIZE 80;
```
