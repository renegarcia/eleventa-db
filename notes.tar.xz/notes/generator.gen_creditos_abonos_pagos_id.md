---
id: 3gwxaadvcnefk834g762bno
title: GEN_CREDITOS_ABONOS_PAGOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CREDITOS_ABONOS_PAGOS_ID;
```
