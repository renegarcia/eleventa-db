---
id: 61f9nx5lk1bkvrdaxoym4oe
title: GEN_ABONOS_VENTAS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_ABONOS_VENTAS_ID;
```
