---
id: 3t31qqcgk40l7j0ufu0jiz5
title: TNUMERODETELEFONO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TNUMERODETELEFONO AS BIGINT;
```
