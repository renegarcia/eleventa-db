---
id: yle4kahq90tqlee6mzf7two
title: ABONOS_ID_IDX
desc: null
updated: 1684912753
created: 1684912753
---


```sql
CREATE INDEX ABONOS_ID_IDX ON ABONOS (ID, CLIENTESV2_CREDITO_ID, DEVUELTO_EN);
```
