---
id: 3mic9eofq8a6qtutv6mokwf
title: GEN_CACHE_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CACHE_ID;
```
