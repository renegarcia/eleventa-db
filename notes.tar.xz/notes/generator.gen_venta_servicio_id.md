---
id: 6qy8y07vgxos5ps6fpxzfhj
title: GEN_VENTA_SERVICIO_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_VENTA_SERVICIO_ID;
```
