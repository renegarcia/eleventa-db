---
id: 53smt8e8f69sw737e2mw4i0
title: TNOTA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TNOTA AS BLOB SUB_TYPE 0 SEGMENT SIZE 80;
```
