---
id: 5i3e8nd4zia1begoi8oteur
title: GEN_INVENTARIO_AJUSTES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_INVENTARIO_AJUSTES_ID;
```
