---
id: l0j264wb58jaid0yt3izc90
title: TFACTURAPAC
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFACTURAPAC AS VARCHAR(3);
```
