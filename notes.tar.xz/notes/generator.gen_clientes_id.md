---
id: 3sortw72ofild0e7bi5d59v
title: GEN_CLIENTES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CLIENTES_ID;
```
