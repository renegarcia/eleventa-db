---
id: 80zq0st6ewivl51rz1x0f8v
title: TCURRENCY
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCURRENCY AS NUMERIC(18, 4)
         DEFAULT 0;
```
