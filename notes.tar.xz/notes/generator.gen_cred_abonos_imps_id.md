---
id: 5ggh8qc17o8menem4r1dqcv
title: GEN_CRED_ABONOS_IMPS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CRED_ABONOS_IMPS_ID;
```
