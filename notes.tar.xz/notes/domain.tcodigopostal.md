---
id: 3d3jb1shazr84577s33ln6a
title: TCODIGOPOSTAL
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TCODIGOPOSTAL AS INTEGER;
```
