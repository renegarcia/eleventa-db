---
id: 3ky0wpqhr3ihptovfafftis
title: GEN_PAGOS_MIXTOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_PAGOS_MIXTOS_ID;
```
