---
id: 73ujesqcst0j6y1z3pzor65
title: IDX_VT_FECHA
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IDX_VT_FECHA ON VENTATICKETS (VENDIDO_EN);
```
