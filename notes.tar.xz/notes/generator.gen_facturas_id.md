---
id: 4vnvrd85uzy1khd6f2gmc2r
title: GEN_FACTURAS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_FACTURAS_ID;
```
