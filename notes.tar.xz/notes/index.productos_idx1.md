---
id: 47hxmw9hzm0v0lb4hreaqdj
title: PRODUCTOS_IDX1
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX PRODUCTOS_IDX1 ON PRODUCTOS (DINVENTARIO, DINVMINIMO);
```
