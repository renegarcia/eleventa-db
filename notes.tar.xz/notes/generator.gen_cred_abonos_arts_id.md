---
id: 7iikjmy7a1ns5gf2hbf2ihn
title: GEN_CRED_ABONOS_ARTS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CRED_ABONOS_ARTS_ID;
```
