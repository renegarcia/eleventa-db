---
id: namkj8h6i4ok44dqop8mc30
title: GEN_IMPUESTOS_REGLAS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_IMPUESTOS_REGLAS_ID;
```
