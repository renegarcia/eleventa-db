---
id: 6kjyj1mrzg33ssq844yd2ym
title: GEN_TICKETS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_TICKETS_ID;
```
