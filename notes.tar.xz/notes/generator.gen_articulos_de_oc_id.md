---
id: 3vpowd72ci45xmixhg7f33c
title: GEN_ARTICULOS_DE_OC_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_ARTICULOS_DE_OC_ID;
```
