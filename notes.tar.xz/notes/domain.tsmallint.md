---
id: y057sqpf8s9zpfsp8yxex1y
title: TSMALLINT
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TSMALLINT AS SMALLINT;
```
