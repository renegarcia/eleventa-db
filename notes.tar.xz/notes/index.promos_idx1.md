---
id: 38o8x7dphlsa2f9blzbuxbm
title: PROMOS_IDX1
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX PROMOS_IDX1 ON PROMOCIONES_POR_CANTIDAD (PRODUCTO_CODIGO);
```
