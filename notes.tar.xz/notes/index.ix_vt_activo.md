---
id: 4thyl6x8jyl4l651xeo4y03
title: IX_VT_ACTIVO
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IX_VT_ACTIVO ON VENTATICKETS (ACTIVO);
```
