---
id: 813u0mb7t7m42lwlai0d9dy
title: GEN_PROVEEDORES_BASE_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_PROVEEDORES_BASE_ID;
```
