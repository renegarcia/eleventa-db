---
id: 61d8uv857k33e4raigs34n0
title: GEN_ORDENES_DE_COMPRA_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_ORDENES_DE_COMPRA_ID;
```
