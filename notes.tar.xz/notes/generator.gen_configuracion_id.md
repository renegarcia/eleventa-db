---
id: ff4gy2cbear2mj6gl7k61lv
title: GEN_CONFIGURACION_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CONFIGURACION_ID;
```
