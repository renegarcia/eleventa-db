---
id: 1camjd0pfrgg7ksnccdi56g
title: GEN_TICKET_ARTICULOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_TICKET_ARTICULOS_ID;
```
