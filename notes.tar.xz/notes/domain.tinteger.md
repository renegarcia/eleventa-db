---
id: 3873pufvtt7tzlhwkctlkev
title: TINTEGER
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TINTEGER AS INTEGER
         DEFAULT 0;
```
