---
id: 7miytip9zfs8fix008elmv0
title: GEN_OPERACIONES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_OPERACIONES_ID;
```
