---
id: 3emtrj745fzekef1iuivrrd
title: GEN_PROVEEDORES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_PROVEEDORES_ID;
```
