---
id: 6uercvutx9q3mamftv4htvw
title: GEN_ABONO_TICKETS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_ABONO_TICKETS_ID;
```
