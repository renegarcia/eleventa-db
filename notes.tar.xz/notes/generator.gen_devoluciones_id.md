---
id: 3995pvdjmi9nc87ezt1xs0a
title: GEN_DEVOLUCIONES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_DEVOLUCIONES_ID;
```
