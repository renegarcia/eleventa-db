---
id: 4owi79oiqex7ziujxrx88qi
title: IX_CT_CAJERO
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IX_CT_CAJERO ON CREDITOS_TRANSACCIONES (CAJERO_ID);
```
