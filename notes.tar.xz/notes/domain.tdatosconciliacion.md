---
id: hty9dnptg9s1gq3uq7pp6qj
title: TDATOSCONCILIACION
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TDATOSCONCILIACION AS VARCHAR(264);
```
