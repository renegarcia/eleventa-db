---
id: 6od78xkj3e518tftpegxl4f
title: GEN_FACTURACION_FOLIOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_FACTURACION_FOLIOS_ID;
```
