---
id: 17h03tc5wncdrcm2jruirsv
title: TFACTURAFOLIO
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TFACTURAFOLIO AS INTEGER NOT NULL;
```
