---
id: 73jsvencgfxkartodajznfd
title: GEN_CORTE_IMP_COBRA_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_CORTE_IMP_COBRA_ID;
```
