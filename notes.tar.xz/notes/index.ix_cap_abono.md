---
id: 86tap4ptgac2ftwhwukodmk
title: IX_CAP_ABONO
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IX_CAP_ABONO ON CREDITOS_ABONOS_PAGOS (ABONO_ID);
```
