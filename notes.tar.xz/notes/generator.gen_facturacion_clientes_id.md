---
id: 5riakapmhbpu7exzgt5z01r
title: GEN_FACTURACION_CLIENTES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_FACTURACION_CLIENTES_ID;
```
