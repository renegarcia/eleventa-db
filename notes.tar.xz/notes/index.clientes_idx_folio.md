---
id: 7o0lj3kmw17ibeu4nxyvlsk
title: CLIENTES_IDX_FOLIO
desc: null
updated: 1684912753
created: 1684912753
---


```sql
CREATE INDEX CLIENTES_IDX_FOLIO ON CLIENTES (FOLIO);
```
