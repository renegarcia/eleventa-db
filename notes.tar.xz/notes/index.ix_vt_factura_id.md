---
id: 4dzax5sjcmjd09xdqx6x3tm
title: IX_VT_FACTURA_ID
desc: null
updated: 1684912754
created: 1684912754
---


```sql
CREATE INDEX IX_VT_FACTURA_ID ON VENTATICKETS (FACTURA_ID);
```
