---
id: 14eg1opiym7nkzssy5vlsqc
title: TTIPOFACTURA
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE DOMAIN TTIPOFACTURA AS CHAR(1)
         DEFAULT 'n' NOT NULL;
```
