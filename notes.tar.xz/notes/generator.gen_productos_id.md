---
id: 5sfdrgsdeseh1jxoiadfbu4
title: GEN_PRODUCTOS_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_PRODUCTOS_ID;
```
