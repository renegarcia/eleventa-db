---
id: 6momvi7d6hwm9pdyzi0na1a
title: GEN_FACTURACION_EMISORES_ID
desc: null
updated: 1684912751
created: 1684912751
---


```sql
CREATE GENERATOR GEN_FACTURACION_EMISORES_ID;
```
